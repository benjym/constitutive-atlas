file(REMOVE_RECURSE
  "CMakeFiles/atlas_path_capability.dir/generated/path_api.cpp.o"
  "CMakeFiles/atlas_path_capability.dir/generated/path_api.cpp.o.d"
  "generated/path_api.cpp"
  "generated/path_catalogue.json"
  "generated/path_models.hpp"
  "libatlas_path_capability.dylib"
  "libatlas_path_capability.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/atlas_path_capability.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
