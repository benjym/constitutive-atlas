file(REMOVE_RECURSE
  "CMakeFiles/atlas_barodesy_rate_probe.dir/tests/barodesy_rate_driver.cpp.o"
  "CMakeFiles/atlas_barodesy_rate_probe.dir/tests/barodesy_rate_driver.cpp.o.d"
  "barodesy-rates.js"
  "barodesy-rates.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/atlas_barodesy_rate_probe.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
