file(REMOVE_RECURSE
  "CMakeFiles/atlas_clay2014_rate_probe.dir/tests/research_rate_driver.cpp.o"
  "CMakeFiles/atlas_clay2014_rate_probe.dir/tests/research_rate_driver.cpp.o.d"
  "clay2014-rates.js"
  "clay2014-rates.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/atlas_clay2014_rate_probe.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
