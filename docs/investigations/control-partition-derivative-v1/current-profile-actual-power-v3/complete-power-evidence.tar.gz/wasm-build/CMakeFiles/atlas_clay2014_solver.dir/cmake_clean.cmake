file(REMOVE_RECURSE
  "CMakeFiles/atlas_clay2014_solver.dir/cpp/main.cpp.o"
  "CMakeFiles/atlas_clay2014_solver.dir/cpp/main.cpp.o.d"
  "clay2014-paths.js"
  "clay2014-paths.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/atlas_clay2014_solver.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
