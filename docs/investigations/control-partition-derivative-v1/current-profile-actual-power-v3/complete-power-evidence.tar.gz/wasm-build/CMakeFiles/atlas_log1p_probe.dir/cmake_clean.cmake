file(REMOVE_RECURSE
  "CMakeFiles/atlas_log1p_probe.dir/tests/log1p_driver.cpp.o"
  "CMakeFiles/atlas_log1p_probe.dir/tests/log1p_driver.cpp.o.d"
  "log1p-fixtures.js"
  "log1p-fixtures.pdb"
  "log1p-generated/models.hpp"
  "log1p-generated/models.json"
  "log1p-history-generated/history_programs.hpp"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/atlas_log1p_probe.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
