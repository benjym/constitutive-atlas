file(REMOVE_RECURSE
  "CMakeFiles/atlas_history_solver.dir/cpp/history_main.cpp.o"
  "CMakeFiles/atlas_history_solver.dir/cpp/history_main.cpp.o.d"
  "history-fixtures.js"
  "history-fixtures.pdb"
  "history-generated/history_programs.hpp"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/atlas_history_solver.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
