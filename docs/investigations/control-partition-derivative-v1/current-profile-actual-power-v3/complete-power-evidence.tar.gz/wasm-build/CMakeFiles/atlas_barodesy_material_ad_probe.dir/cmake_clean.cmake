file(REMOVE_RECURSE
  "CMakeFiles/atlas_barodesy_material_ad_probe.dir/tests/barodesy_material_ad_driver.cpp.o"
  "CMakeFiles/atlas_barodesy_material_ad_probe.dir/tests/barodesy_material_ad_driver.cpp.o.d"
  "barodesy-material-ad.js"
  "barodesy-material-ad.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/atlas_barodesy_material_ad_probe.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
