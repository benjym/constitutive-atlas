file(REMOVE_RECURSE
  "CMakeFiles/atlas_research_solver.dir/cpp/main.cpp.o"
  "CMakeFiles/atlas_research_solver.dir/cpp/main.cpp.o.d"
  "research.js"
  "research.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/atlas_research_solver.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
