file(REMOVE_RECURSE
  "CMakeFiles/atlas_burgers_solver.dir/cpp/main.cpp.o"
  "CMakeFiles/atlas_burgers_solver.dir/cpp/main.cpp.o.d"
  "burgers.mjs"
  "burgers.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/atlas_burgers_solver.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
