file(REMOVE_RECURSE
  "CMakeFiles/atlas_clay2013_solver.dir/cpp/main.cpp.o"
  "CMakeFiles/atlas_clay2013_solver.dir/cpp/main.cpp.o.d"
  "clay2013.js"
  "clay2013.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/atlas_clay2013_solver.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
