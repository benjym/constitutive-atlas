file(REMOVE_RECURSE
  "CMakeFiles/atlas_power_creep_models"
  "power-creep-generated/models.hpp"
  "power-creep-generated/models.json"
)

# Per-language clean rules from dependency scanning.
foreach(lang )
  include(CMakeFiles/atlas_power_creep_models.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
