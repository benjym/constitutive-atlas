file(REMOVE_RECURSE
  "CMakeFiles/atlas_numerical_tests.dir/tests/test_solver.cpp.o"
  "CMakeFiles/atlas_numerical_tests.dir/tests/test_solver.cpp.o.d"
  "atlas_numerical_tests"
  "atlas_numerical_tests.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/atlas_numerical_tests.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
