file(REMOVE_RECURSE
  "CMakeFiles/atlas_gis2024_models"
  "gis2024-generated/models.hpp"
)

# Per-language clean rules from dependency scanning.
foreach(lang )
  include(CMakeFiles/atlas_gis2024_models.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
