file(REMOVE_RECURSE
  "CMakeFiles/atlas_clay2014_models"
  "clay2014-generated/models.hpp"
  "clay2014-generated/models.json"
)

# Per-language clean rules from dependency scanning.
foreach(lang )
  include(CMakeFiles/atlas_clay2014_models.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
