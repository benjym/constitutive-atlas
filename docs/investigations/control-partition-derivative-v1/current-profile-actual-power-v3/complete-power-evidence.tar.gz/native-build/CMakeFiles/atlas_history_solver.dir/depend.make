# Empty dependencies file for atlas_history_solver.
# This may be replaced when dependencies are built.
