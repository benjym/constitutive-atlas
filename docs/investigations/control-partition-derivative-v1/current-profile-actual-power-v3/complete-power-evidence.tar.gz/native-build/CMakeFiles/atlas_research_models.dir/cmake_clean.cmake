file(REMOVE_RECURSE
  "CMakeFiles/atlas_research_models"
  "research-generated/models.hpp"
)

# Per-language clean rules from dependency scanning.
foreach(lang )
  include(CMakeFiles/atlas_research_models.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
