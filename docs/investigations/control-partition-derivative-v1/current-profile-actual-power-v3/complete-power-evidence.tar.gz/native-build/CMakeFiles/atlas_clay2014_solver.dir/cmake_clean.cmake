file(REMOVE_RECURSE
  "CMakeFiles/atlas_clay2014_solver.dir/tests/research_integrate_driver.cpp.o"
  "CMakeFiles/atlas_clay2014_solver.dir/tests/research_integrate_driver.cpp.o.d"
  "atlas_clay2014_solver"
  "atlas_clay2014_solver.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/atlas_clay2014_solver.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
