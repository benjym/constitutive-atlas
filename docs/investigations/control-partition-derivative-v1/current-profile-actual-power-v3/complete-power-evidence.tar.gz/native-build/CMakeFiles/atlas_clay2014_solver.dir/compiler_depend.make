# Empty compiler generated dependencies file for atlas_clay2014_solver.
# This may be replaced when dependencies are built.
