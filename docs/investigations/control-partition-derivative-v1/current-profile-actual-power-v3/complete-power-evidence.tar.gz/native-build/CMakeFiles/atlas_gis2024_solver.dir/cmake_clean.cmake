file(REMOVE_RECURSE
  "CMakeFiles/atlas_gis2024_solver.dir/cpp/main.cpp.o"
  "CMakeFiles/atlas_gis2024_solver.dir/cpp/main.cpp.o.d"
  "atlas_gis2024_solver"
  "atlas_gis2024_solver.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/atlas_gis2024_solver.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
