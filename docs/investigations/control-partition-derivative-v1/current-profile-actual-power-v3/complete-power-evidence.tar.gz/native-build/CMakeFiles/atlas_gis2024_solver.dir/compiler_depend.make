# Empty compiler generated dependencies file for atlas_gis2024_solver.
# This may be replaced when dependencies are built.
