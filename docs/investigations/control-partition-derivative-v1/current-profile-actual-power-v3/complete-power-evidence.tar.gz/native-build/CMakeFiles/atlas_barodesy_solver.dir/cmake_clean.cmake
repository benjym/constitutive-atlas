file(REMOVE_RECURSE
  "CMakeFiles/atlas_barodesy_solver.dir/cpp/main.cpp.o"
  "CMakeFiles/atlas_barodesy_solver.dir/cpp/main.cpp.o.d"
  "atlas_barodesy_solver"
  "atlas_barodesy_solver.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/atlas_barodesy_solver.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
