# Empty dependencies file for atlas_barodesy_solver.
# This may be replaced when dependencies are built.
