file(REMOVE_RECURSE
  "CMakeFiles/atlas_barodesy_models"
  "barodesy-rate-generated/models.hpp"
  "barodesy-rate-generated/models.json"
)

# Per-language clean rules from dependency scanning.
foreach(lang )
  include(CMakeFiles/atlas_barodesy_models.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
