# Empty custom commands generated dependencies file for atlas_barodesy_models.
# This may be replaced when dependencies are built.
