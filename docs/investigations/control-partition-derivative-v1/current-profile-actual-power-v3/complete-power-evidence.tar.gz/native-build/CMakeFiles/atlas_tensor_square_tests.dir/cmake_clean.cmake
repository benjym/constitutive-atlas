file(REMOVE_RECURSE
  "CMakeFiles/atlas_tensor_square_tests.dir/tests/test_tensor_square.cpp.o"
  "CMakeFiles/atlas_tensor_square_tests.dir/tests/test_tensor_square.cpp.o.d"
  "atlas_tensor_square_tests"
  "atlas_tensor_square_tests.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/atlas_tensor_square_tests.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
