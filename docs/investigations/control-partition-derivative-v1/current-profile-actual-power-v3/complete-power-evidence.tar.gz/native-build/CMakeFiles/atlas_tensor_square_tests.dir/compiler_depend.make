# Empty compiler generated dependencies file for atlas_tensor_square_tests.
# This may be replaced when dependencies are built.
