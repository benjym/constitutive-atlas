file(REMOVE_RECURSE
  "CMakeFiles/atlas_power_creep_solver.dir/cpp/main.cpp.o"
  "CMakeFiles/atlas_power_creep_solver.dir/cpp/main.cpp.o.d"
  "atlas_power_creep_solver"
  "atlas_power_creep_solver.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/atlas_power_creep_solver.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
