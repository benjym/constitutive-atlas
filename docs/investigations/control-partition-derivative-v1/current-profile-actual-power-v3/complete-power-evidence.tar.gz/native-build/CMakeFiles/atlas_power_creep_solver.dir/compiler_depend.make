# Empty compiler generated dependencies file for atlas_power_creep_solver.
# This may be replaced when dependencies are built.
