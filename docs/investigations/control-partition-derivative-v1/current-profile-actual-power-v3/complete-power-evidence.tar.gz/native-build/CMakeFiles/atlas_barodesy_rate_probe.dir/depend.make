# Empty dependencies file for atlas_barodesy_rate_probe.
# This may be replaced when dependencies are built.
