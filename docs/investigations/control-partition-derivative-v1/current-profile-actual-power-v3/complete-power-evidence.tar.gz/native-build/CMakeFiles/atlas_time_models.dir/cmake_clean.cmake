file(REMOVE_RECURSE
  "CMakeFiles/atlas_time_models"
  "time-generated/models.hpp"
)

# Per-language clean rules from dependency scanning.
foreach(lang )
  include(CMakeFiles/atlas_time_models.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
