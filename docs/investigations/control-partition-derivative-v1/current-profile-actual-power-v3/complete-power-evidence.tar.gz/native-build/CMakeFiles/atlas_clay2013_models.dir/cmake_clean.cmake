file(REMOVE_RECURSE
  "CMakeFiles/atlas_clay2013_models"
  "clay2013-generated/models.hpp"
)

# Per-language clean rules from dependency scanning.
foreach(lang )
  include(CMakeFiles/atlas_clay2013_models.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
