# Empty compiler generated dependencies file for atlas_time_solver.
# This may be replaced when dependencies are built.
