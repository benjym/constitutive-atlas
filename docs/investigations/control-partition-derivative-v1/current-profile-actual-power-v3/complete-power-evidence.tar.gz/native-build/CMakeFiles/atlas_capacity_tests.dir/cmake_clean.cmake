file(REMOVE_RECURSE
  "CMakeFiles/atlas_capacity_tests.dir/tests/test_capacity.cpp.o"
  "CMakeFiles/atlas_capacity_tests.dir/tests/test_capacity.cpp.o.d"
  "atlas_capacity_tests"
  "atlas_capacity_tests.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/atlas_capacity_tests.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
