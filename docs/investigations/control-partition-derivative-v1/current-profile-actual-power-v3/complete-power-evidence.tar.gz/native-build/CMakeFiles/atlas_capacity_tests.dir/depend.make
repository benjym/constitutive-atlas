# Empty dependencies file for atlas_capacity_tests.
# This may be replaced when dependencies are built.
