file(REMOVE_RECURSE
  "CMakeFiles/atlas_scalar_probe.dir/tests/scalar_functions_probe.cpp.o"
  "CMakeFiles/atlas_scalar_probe.dir/tests/scalar_functions_probe.cpp.o.d"
  "libatlas_scalar_probe.dylib"
  "libatlas_scalar_probe.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/atlas_scalar_probe.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
