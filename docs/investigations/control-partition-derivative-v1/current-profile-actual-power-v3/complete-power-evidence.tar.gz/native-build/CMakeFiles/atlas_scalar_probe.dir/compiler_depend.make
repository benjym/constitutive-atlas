# Empty compiler generated dependencies file for atlas_scalar_probe.
# This may be replaced when dependencies are built.
