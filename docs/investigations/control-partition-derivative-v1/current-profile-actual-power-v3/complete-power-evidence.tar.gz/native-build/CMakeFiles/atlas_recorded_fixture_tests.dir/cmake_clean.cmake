file(REMOVE_RECURSE
  "CMakeFiles/atlas_recorded_fixture_tests.dir/tests/test_recorded_fixture.cpp.o"
  "CMakeFiles/atlas_recorded_fixture_tests.dir/tests/test_recorded_fixture.cpp.o.d"
  "atlas_recorded_fixture_tests"
  "atlas_recorded_fixture_tests.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/atlas_recorded_fixture_tests.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
