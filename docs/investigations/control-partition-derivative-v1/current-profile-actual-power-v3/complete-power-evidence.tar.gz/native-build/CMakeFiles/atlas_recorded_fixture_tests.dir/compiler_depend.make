# Empty compiler generated dependencies file for atlas_recorded_fixture_tests.
# This may be replaced when dependencies are built.
