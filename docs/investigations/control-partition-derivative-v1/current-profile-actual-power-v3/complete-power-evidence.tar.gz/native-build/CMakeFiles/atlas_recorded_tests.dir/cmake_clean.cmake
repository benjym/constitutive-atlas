file(REMOVE_RECURSE
  "CMakeFiles/atlas_recorded_tests.dir/tests/test_recorded.cpp.o"
  "CMakeFiles/atlas_recorded_tests.dir/tests/test_recorded.cpp.o.d"
  "atlas_recorded_tests"
  "atlas_recorded_tests.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/atlas_recorded_tests.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
