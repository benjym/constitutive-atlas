# Empty compiler generated dependencies file for atlas_time_tests.
# This may be replaced when dependencies are built.
