file(REMOVE_RECURSE
  "CMakeFiles/atlas_time_tests.dir/tests/test_time.cpp.o"
  "CMakeFiles/atlas_time_tests.dir/tests/test_time.cpp.o.d"
  "atlas_time_tests"
  "atlas_time_tests.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/atlas_time_tests.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
