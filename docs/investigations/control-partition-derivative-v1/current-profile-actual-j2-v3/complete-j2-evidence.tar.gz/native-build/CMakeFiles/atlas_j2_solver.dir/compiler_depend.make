# Empty compiler generated dependencies file for atlas_j2_solver.
# This may be replaced when dependencies are built.
