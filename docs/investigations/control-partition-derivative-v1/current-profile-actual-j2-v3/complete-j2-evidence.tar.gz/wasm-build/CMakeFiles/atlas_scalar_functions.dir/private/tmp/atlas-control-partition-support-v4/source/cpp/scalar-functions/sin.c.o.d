CMakeFiles/atlas_scalar_functions.dir/private/tmp/atlas-control-partition-support-v4/source/cpp/scalar-functions/sin.c.o: \
  /private/tmp/atlas-control-partition-support-v4/source/cpp/scalar-functions/sin.c \
  /private/tmp/atlas-control-partition-support-v4/source/cpp/scalar-functions/libm.h \
  /opt/homebrew/Cellar/emscripten/6.0.8/libexec/llvm/lib/clang/24/include/stdint.h \
  /private/tmp/atlas-predictor-constraints-v1/em-cache-v1/sysroot/include/stdint.h \
  /private/tmp/atlas-predictor-constraints-v1/em-cache-v1/sysroot/include/bits/alltypes.h \
  /opt/homebrew/Cellar/emscripten/6.0.8/libexec/llvm/lib/clang/24/include/float.h \
  /private/tmp/atlas-predictor-constraints-v1/em-cache-v1/sysroot/include/float.h \
  /opt/homebrew/Cellar/emscripten/6.0.8/libexec/llvm/lib/clang/24/include/__float_header_macro.h \
  /opt/homebrew/Cellar/emscripten/6.0.8/libexec/llvm/lib/clang/24/include/__float_float.h \
  /opt/homebrew/Cellar/emscripten/6.0.8/libexec/llvm/lib/clang/24/include/__float_infinity_nan.h \
  /private/tmp/atlas-predictor-constraints-v1/em-cache-v1/sysroot/include/compat/math.h \
  /private/tmp/atlas-predictor-constraints-v1/em-cache-v1/sysroot/include/math.h \
  /private/tmp/atlas-predictor-constraints-v1/em-cache-v1/sysroot/include/features.h
