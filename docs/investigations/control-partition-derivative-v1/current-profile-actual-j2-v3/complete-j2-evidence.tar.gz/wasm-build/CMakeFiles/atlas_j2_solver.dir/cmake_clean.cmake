file(REMOVE_RECURSE
  "CMakeFiles/atlas_j2_solver.dir/private/tmp/atlas-control-partition-support-v4/source/cpp/main.cpp.o"
  "CMakeFiles/atlas_j2_solver.dir/private/tmp/atlas-control-partition-support-v4/source/cpp/main.cpp.o.d"
  "j2.js"
  "j2.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/atlas_j2_solver.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
