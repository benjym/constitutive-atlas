# Empty dependencies file for atlas_burgers_solver.
# This may be replaced when dependencies are built.
