file(REMOVE_RECURSE
  "CMakeFiles/atlas_burgers_models"
  "generated/models.hpp"
  "generated/models.json"
)

# Per-language clean rules from dependency scanning.
foreach(lang )
  include(CMakeFiles/atlas_burgers_models.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
