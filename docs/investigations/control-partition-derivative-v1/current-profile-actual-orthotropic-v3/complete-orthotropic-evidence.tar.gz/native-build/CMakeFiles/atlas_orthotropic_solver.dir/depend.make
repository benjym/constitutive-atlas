# Empty dependencies file for atlas_orthotropic_solver.
# This may be replaced when dependencies are built.
