file(REMOVE_RECURSE
  "CMakeFiles/atlas_sls_solver.dir/private/tmp/atlas-control-partition-support-v4/source/cpp/main.cpp.o"
  "CMakeFiles/atlas_sls_solver.dir/private/tmp/atlas-control-partition-support-v4/source/cpp/main.cpp.o.d"
  "sls.js"
  "sls.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/atlas_sls_solver.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
