# Empty dependencies file for atlas_sls_solver.
# This may be replaced when dependencies are built.
