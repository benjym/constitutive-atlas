file(REMOVE_RECURSE
  "CMakeFiles/atlas_barodesy_material_ad_probe.dir/tests/barodesy_material_ad_driver.cpp.o"
  "CMakeFiles/atlas_barodesy_material_ad_probe.dir/tests/barodesy_material_ad_driver.cpp.o.d"
  "atlas_barodesy_material_ad_probe"
  "atlas_barodesy_material_ad_probe.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/atlas_barodesy_material_ad_probe.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
