file(REMOVE_RECURSE
  "CMakeFiles/atlas_maxwell_solver.dir/private/tmp/atlas-control-partition-support-v4/source/cpp/main.cpp.o"
  "CMakeFiles/atlas_maxwell_solver.dir/private/tmp/atlas-control-partition-support-v4/source/cpp/main.cpp.o.d"
  "atlas_maxwell_solver"
  "atlas_maxwell_solver.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/atlas_maxwell_solver.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
