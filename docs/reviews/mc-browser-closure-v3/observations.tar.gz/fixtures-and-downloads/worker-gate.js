async (page) => {
 return await page.evaluate(async()=>{
  const {catalogue,rows}=await (await fetch('/fixtures/corpus.json')).json();
  const stable=v=>JSON.stringify(v&&typeof v==='object'?Array.isArray(v)?v.map(x=>JSON.parse(stable(x))):Object.fromEntries(Object.keys(v).sort().map(k=>[k,JSON.parse(stable(v[k]))])):v);
  const strip=r=>Object.fromEntries(Object.entries(r).filter(([k])=>k!=='elapsed_ms'));
  const results=[];
  for(const row of rows){
   const worker=new Worker('./worker.js',{type:'module'});
   let reply;
   try{reply=await new Promise((resolve,reject)=>{const timer=setTimeout(()=>reject(Error('worker timeout '+row.id)),15000);worker.onmessage=e=>{clearTimeout(timer);resolve(e.data)};worker.onerror=e=>{clearTimeout(timer);reject(Error(e.message))};worker.postMessage({id:row.id,kind:'laboratory',specification:row.specification,catalogue});});}finally{worker.terminate();}
   results.push({id:row.id,passed:!reply.error&&stable(strip(reply.result))===stable(strip(row.expected)),reply});
  }
  return {gate:'P03',passed:results.every(r=>r.passed),requests:results.length,results};
 });
}
