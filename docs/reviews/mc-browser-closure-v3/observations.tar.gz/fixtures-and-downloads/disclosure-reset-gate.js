async (page)=>{
 const observations={};
 await page.getByRole('combobox',{name:'Select a model',exact:true}).selectOption('mohr-coulomb');
 await page.waitForFunction(()=>!document.getElementById('export-run').disabled&&document.getElementById('run-state').textContent.includes('up to date'));
 await page.getByRole('combobox',{name:'Experimental test',exact:true}).selectOption({label:'OPARA-TXCD-100 · 104 kPa · e₀ 0.416'});
 await page.getByRole('button',{name:'Match available test inputs',exact:true}).waitFor({state:'visible'});
 observations.matching={label:await page.locator('#match-experiment').textContent(),enabled:await page.locator('#match-experiment').isEnabled(),voidRatioInputs:await page.locator('#state-e').count(),hint:await page.getByText('Matching uses supplied stress and protocol, and void ratio only when this model provides that input. Other internal-state inputs keep their explicit values; specimen preparation remains unassessed.',{exact:true}).textContent()};
 const showing=await page.getByRole('switch',{name:'Show measurements',exact:true}).isChecked();await page.getByRole('switch',{name:'Show measurements',exact:true}).uncheck();observations.toggle={initiallyShowing:showing,hidden:!(await page.getByRole('switch',{name:'Show measurements',exact:true}).isChecked())};await page.getByRole('switch',{name:'Show measurements',exact:true}).check();
 await page.getByRole('button',{name:'Match available test inputs',exact:true}).click();
 await page.waitForFunction(()=>!document.getElementById('export-run').disabled&&document.getElementById('run-state').textContent.includes('up to date'));
 observations.matchedStress=await page.locator('#confinement').inputValue();
 await page.getByRole('combobox',{name:'Select a model',exact:true}).selectOption('tresca-associated-perfect-bk2022v1-be');
 await page.waitForFunction(()=>!document.getElementById('export-run').disabled&&document.getElementById('run-state').textContent.includes('up to date'));
 observations.totalStressGuard={matchingDisabled:await page.locator('#match-experiment').isDisabled(),status:await page.locator('#experiment-status').textContent(),voidRatioInputs:await page.locator('#state-e').count()};
 await page.getByRole('combobox',{name:'Select a model',exact:true}).selectOption('mohr-coulomb');await page.getByRole('button',{name:'Reset',exact:true}).click();
 await page.waitForFunction(()=>!document.getElementById('export-run').disabled&&document.getElementById('run-state').textContent.includes('up to date'));
 observations.reset={model:await page.locator('#model').inputValue(),target:await page.locator('#target').inputValue(),cycles:await page.locator('#cycles').inputValue(),confinement:await page.locator('#confinement').inputValue(),voidRatioInputs:await page.locator('#state-e').count()};
 await page.screenshot({path:'/private/tmp/atlas-mc-private-package-v3-attempt4/matching-corrected.png',fullPage:true});
 return observations;
}
