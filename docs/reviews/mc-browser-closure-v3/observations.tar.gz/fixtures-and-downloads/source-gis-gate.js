async(page)=>{
 const observations={};
 await page.getByRole('combobox',{name:'Select a model',exact:true}).selectOption('research-hp-extracted-asbs-gis-2024-v03');await page.getByRole('button',{name:'Reset',exact:true}).click();
 await page.waitForFunction(()=>document.getElementById('run-state').textContent.includes('Stopped')||document.getElementById('run-state').textContent.includes('attention'));
 observations.gisOrdinary={status:await page.locator('#run-state').textContent(),message:await page.locator('#control-status').textContent()};
 await page.locator('#named-examples summary').click();await page.locator('#named-example').selectOption('gis2024-small-drained');await page.waitForFunction(()=>!document.getElementById('load-named-example').disabled);await page.getByRole('button',{name:'Replace inputs with this example',exact:true}).click();await page.waitForFunction(()=>!document.getElementById('export-run').disabled&&document.getElementById('run-state').textContent.includes('up to date'));
 observations.gisNamed={status:await page.locator('#run-state').textContent(),detail:await page.locator('#run-detail').textContent(),limits:await page.locator('#named-example-status').textContent()};
 const [download]=await Promise.all([page.waitForEvent('download'),page.getByRole('button',{name:'↓ Reproducible run',exact:true}).click()]);await download.saveAs('/private/tmp/atlas-mc-browser-v3/roundtrip/gis-named.json');
 await page.getByRole('link').filter({hasText:'Model catalogue'}).click();await page.locator('a[href="#catalogue/mohr-coulomb"]').first().click();await page.locator('#catalogue-dialog').waitFor({state:'visible'});
 observations.catalogue={status:await page.locator('#catalogue-detail-status').textContent(),text:await page.locator('#catalogue-detail-body').innerText(),links:await page.locator('#catalogue-detail-body a').evaluateAll(links=>links.map(a=>({text:a.textContent,href:a.href})))};
 const dossier=page.getByRole('link',{name:'Source dossier',exact:true});await page.locator('summary').filter({hasText:'Review identity and evidence references'}).click();
 const [popup]=await Promise.all([page.waitForEvent('popup'),dossier.click()]);await popup.waitForLoadState('domcontentloaded');observations.dossier={url:popup.url(),text:await popup.locator('body').innerText()};await popup.close();
 observations.authors=await page.locator('.sidebar a').allTextContents();
 await page.screenshot({path:'/private/tmp/atlas-mc-private-package-v3-attempt4/mc-source-review.png',fullPage:true});return observations;
}
