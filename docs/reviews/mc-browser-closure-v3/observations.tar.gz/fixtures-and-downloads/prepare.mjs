import fs from'node:fs/promises';
import {createHash}from'node:crypto';
import {createLaboratoryDocument,parseLaboratoryDocument}from'/Users/bmar5496/code/constitutive-atlas/web/laboratory-document.mjs';
const root='/Users/bmar5496/code/constitutive-atlas';const read=async p=>JSON.parse(await fs.readFile(p,'utf8'));
const journal=await read('./journal.json'),catalogue=JSON.parse(journal.find(r=>r.id==='describe').raw),contracts=await read(root+'/docs/reviews/mc-current-collector-freeze-v3/contracts.json');
await fs.mkdir('./imports');const imports=[];
for(const c of contracts){const row=journal.find(r=>r.id===c.id);if(!row)throw Error(c.id);const result=JSON.parse(row.raw);const doc=createLaboratoryDocument(c.specification,result,catalogue);const text=JSON.stringify(doc,null,2)+'\n';const specification=parseLaboratoryDocument(text,catalogue);if(JSON.stringify(specification)!==JSON.stringify(c.specification))throw Error('Specification changed');const file=c.id.replaceAll('/','--')+'.json';await fs.writeFile('./imports/'+file,text);imports.push({id:c.id,file,sha256:createHash('sha256').update(text).digest('hex'),points:result.points.length});}
const compat=await read('./compatibility.json'),requests=await read(root+'/catalogue/investigations/declared-loading-mixed-v1/requests.json');
const corpus={catalogue,rows:[...contracts.map(c=>({id:c.id,specification:c.specification,expected:JSON.parse(journal.find(r=>r.id===c.id).raw)})),...requests.map(c=>({id:c.id,specification:c.specification,expected:JSON.parse(compat.rows.find(r=>r.id===c.id).raw)}))]};
await fs.writeFile('./corpus.json',JSON.stringify(corpus));await fs.writeFile('./fixture-index.json',JSON.stringify({imports,points:imports.reduce((n,x)=>n+x.points,0),provenance:'Saved qualified Wasm journal, not source-ideal replacement or new numerical result'},null,2)+'\n');
console.log(JSON.stringify({imports:imports.length,points:imports.reduce((n,x)=>n+x.points,0),worker_requests:corpus.rows.length}));
