async(page)=>{
 const observations={roundtrips:[],invalidImports:[],parameterRecovery:[]};
 for(const file of ['protocol-1--monotonic.json','protocol-1--cyclic.json']){
  await page.reload();await page.waitForFunction(()=>!document.getElementById('export-run').disabled);
  await page.locator('#run-file').setInputFiles('/private/tmp/atlas-mc-browser-v3/exports/'+file);
  await page.waitForFunction(()=>document.getElementById('model').value==='mohr-coulomb'&&!document.getElementById('export-run').disabled&&document.getElementById('run-state').textContent.includes('up to date'));
  const [download]=await Promise.all([page.waitForEvent('download'),page.getByRole('button',{name:'↓ Reproducible run',exact:true}).click()]);await download.saveAs('/private/tmp/atlas-mc-browser-v3/roundtrip/'+file);observations.roundtrips.push(file);
 }
 const [csv]=await Promise.all([page.waitForEvent('download'),page.getByRole('button',{name:'↓ Results CSV',exact:true}).click()]);await csv.saveAs('/private/tmp/atlas-mc-browser-v3/roundtrip/cyclic.csv');
 await page.evaluate(()=>{window.__workerCalls=0;window.__originalPost=Worker.prototype.postMessage;Worker.prototype.postMessage=function(...args){window.__workerCalls++;return window.__originalPost.apply(this,args);};});
 for(const [file,message]of [['duplicate.json','Duplicate JSON key:'],['overflow.json','JSON number outside finite binary64 range.'],['stale.json','Invalid scoped laboratory envelope or catalogue.']]){
  await page.locator('#run-file').setInputFiles('/private/tmp/atlas-mc-browser-v3/negative/'+file);await page.waitForFunction(text=>document.getElementById('toast').textContent.includes(text),message);observations.invalidImports.push({file,message:await page.locator('#toast').textContent(),workerCalls:await page.evaluate(()=>window.__workerCalls)});
 }
 await page.evaluate(()=>{Worker.prototype.postMessage=window.__originalPost;delete window.__originalPost;});
 await page.getByRole('button',{name:'Reset',exact:true}).click();await page.waitForFunction(()=>!document.getElementById('export-run').disabled&&document.getElementById('run-state').textContent.includes('up to date'));
 await page.locator('summary').filter({hasText:'Material parameters'}).click();await page.locator('#param-c').fill('0');await page.locator('#param-c').press('Tab');
 await page.waitForFunction(()=>document.getElementById('run-state').textContent.includes('Stopped')||document.getElementById('run-state').textContent.includes('attention'));
 observations.parameterRecovery.push({case:'c=0',status:await page.locator('#run-state').textContent(),message:await page.locator('#control-status').textContent()});
 await page.getByRole('button',{name:'Reset',exact:true}).click();await page.waitForFunction(()=>!document.getElementById('export-run').disabled&&document.getElementById('run-state').textContent.includes('up to date'));observations.parameterRecovery.push({case:'c recovery',status:await page.locator('#run-state').textContent()});
 await page.locator('summary').filter({hasText:'Initial state details'}).click();await page.locator('#stress-ratio').fill('10');await page.locator('#stress-ratio').press('Tab');
 await page.waitForFunction(()=>document.getElementById('run-state').textContent.includes('Stopped')||document.getElementById('run-state').textContent.includes('attention'));
 observations.parameterRecovery.push({case:'inadmissible initial',status:await page.locator('#run-state').textContent(),message:await page.locator('#control-status').textContent()});
 await page.getByRole('button',{name:'Reset',exact:true}).click();await page.waitForFunction(()=>!document.getElementById('export-run').disabled&&document.getElementById('run-state').textContent.includes('up to date'));observations.parameterRecovery.push({case:'initial recovery',status:await page.locator('#run-state').textContent()});
 const [recovered]=await Promise.all([page.waitForEvent('download'),page.getByRole('button',{name:'↓ Reproducible run',exact:true}).click()]);await recovered.saveAs('/private/tmp/atlas-mc-browser-v3/roundtrip/recovered-default.json');
 return observations;
}
