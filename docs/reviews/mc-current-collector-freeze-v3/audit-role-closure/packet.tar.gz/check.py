import pathlib,json,sys,tempfile,copy,math
P=pathlib.Path(__file__).parent;S=P/'snapshot';sys.path.insert(0,str(S))
from assess_replays import assess,export_equal
from assess_paths import assess as paths
read=lambda p:json.loads(p.read_text())
base={n:read(P/'observer-synthetic'/n)for n in ['journal.json','calls.json','replays.json','rejections.json']}
results={'observer_synthetic':assess(P/'observer-synthetic','synthetic'),'path_ideal':paths(base['journal.json'],read(S/'requests.json'),read(S/'reference/reference-p360.json'),read(S/'generated/models.json')),'rejections':[]}
with tempfile.TemporaryDirectory()as t:
 D=pathlib.Path(t)
 def run(label,data,role,accept=False):
  for n,v in data.items():(D/n).write_text(json.dumps(v))
  try:assess(D,role);ok=True
  except Exception:ok=False
  assert ok==accept,label
  results['rejections'].append({'label':label,'accepted':ok})
 native=copy.deepcopy(base)
 for c in native['calls.json']:
  ok=json.loads(c['raw']).get('ok',True);c['process']={'status':0 if ok else 1,'signal':None,'error':None,'stderr':''}
 run('manufactured native receipts',native,'native',True)
 run('native missing all',base,'native')
 run('wasm with native',native,'wasm')
 run('wasm without native',base,'wasm',True)
 for idx in [0,1,2,57,58,92]:
  d=copy.deepcopy(native);d['calls.json'][idx].pop('process');run('missing native receipt '+str(idx),d,'native')
 req=read(S/'requests.json');rows=copy.deepcopy(base['journal.json']);ref=read(S/'reference/reference-p360.json');cat=read(S/'generated/models.json')
 changed=[]
 for row in rows[1:]:
  v=row['request']['target']
  if float(v).is_integer():row['request']['target']=int(v);changed.append(row['id'])
 assert changed
 paths(rows,req,ref,cat);results['target_json_integer_spelling_accepts']=changed
 row=next(r for r in rows[1:]if r['id'] in changed);old=row['request']['target'];row['request']['target']=math.nextafter(float(old),math.inf)
 try:paths(rows,req,ref,cat)
 except Exception:results['next_binary64_target_rejected']=True
 else:raise AssertionError('changed target accepted')
assert export_equal({'target':1.0,'zero':-0.0},{'target':1,'zero':0})
assert not export_equal({'target':True},{'target':1})
assert not export_equal({'target':math.nextafter(1.,2.)},{'target':1})
results['export_numeric_spelling_and_signed_zero_only']=True
assert (S/'policy.json').read_bytes()==(pathlib.Path('/private/tmp/atlas-mc-current-collector-audit-v3/snapshot/policy.json')).read_bytes();results['policy_bytes_unchanged']=True
(P/'checks.json').write_text(json.dumps(results,indent=2)+'\n');print('closure passes')
