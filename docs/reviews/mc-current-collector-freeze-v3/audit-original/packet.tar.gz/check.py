from pathlib import Path
import json,copy,sys,tempfile,hashlib
P=Path(__file__).parent;S=P/'snapshot';sys.path.insert(0,str(S))
from assess_replays import assess
from assess_paths import assess as paths
from assess_parity import assess as parity
read=lambda p:json.loads(p.read_text())
original={n:read(S/'synthetic'/n) for n in ['journal.json','replays.json','rejections.json','calls.json']}
req=read(S/'requests.json');ref=read(S/'reference/reference-p360.json');cat=read(S/'generated/models.json')
results={'source_ideal_paths':paths(original['journal.json'],req,ref,cat),'source_ideal_parity':parity(original['journal.json'],original['journal.json'],req),'checks':[]}
with tempfile.TemporaryDirectory(prefix='atlas-mc-audit-') as t:
 D=Path(t)
 def run(label,mutate,expected=False):
  d=copy.deepcopy(original);mutate(d)
  assert d!=original,label+' no-op'
  for n,x in d.items():(D/n).write_text(json.dumps(x))
  try: assess(D);accepted=True;error=None
  except Exception as e:accepted=False;error=type(e).__name__+':'+str(e)
  results['checks'].append({'label':label,'accepted':accepted,'expected_acceptance':expected,'error':error})
  assert accepted==expected,label
 for n,x in original.items():(D/n).write_text(json.dumps(x))
 results['source_ideal_replays']=assess(D)
 run('extra94thcall',lambda d:d['calls.json'].append(copy.deepcopy(d['calls.json'][-1])))
 run('missing93rdcall',lambda d:d['calls.json'].pop())
 for field,value in [('status',2),('status',True),('signal','SIGKILL'),('error','timeout'),('stderr','warning')]:
  run('process_'+field+'_'+str(value),lambda d,f=field,v=value:d['calls.json'][2]['process'].__setitem__(f,v))
 run('wrong_success_status1',lambda d:d['calls.json'][2]['process'].__setitem__('status',1))
 run('wrong_rejection_status0',lambda d:d['calls.json'][57]['process'].__setitem__('status',0))
 run('remove_all_native_process_receipts',lambda d:[c.pop('process',None) for c in d['calls.json']],True)
 def raw_mut(d,index,kind):
  c=d['calls.json'][index];r=c['raw'];c['raw']=('{"unused":1e999,'+r[1:])if kind=='overflow'else('{"ok":false,'+r[1:])
  if index==2:d['journal.json'][1]['raw']=c['raw']
 run('unused_nested_raw_overflow',lambda d:raw_mut(d,2,'overflow'))
 run('duplicate_raw_ok',lambda d:raw_mut(d,2,'duplicate'))
 run('describe_extra_unused_overflow',lambda d:d['calls.json'][1].__setitem__('raw','{"unused":1e999,'+d['calls.json'][1]['raw'][1:]))
(P/'checks.json').write_text(json.dumps(results,indent=2)+'\n')
print('checks',len(results['checks']))
