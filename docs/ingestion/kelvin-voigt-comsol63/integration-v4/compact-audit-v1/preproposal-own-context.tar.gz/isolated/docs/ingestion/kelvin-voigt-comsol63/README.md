# Kelvin–Voigt COMSOL 6.3

Exact ordinary isotropic Kelvin–Voigt law with deviatoric viscosity, purely elastic bulk and six persistent infinitesimal strains. Fixed spatial frame, zero spin, dry total Cauchy stress; compression-positive Mandel components. All loading is in physical seconds.

The complete equation inventory, original-source receipts, parameter/state/domain/convention crosswalk, initialization and transaction contract, rights, independent analytical checks and reproducible commands are in [the source packet](source-v1/README.md). [The delivery ledger](DELIVERY.md) distinguishes scientific verification, approval, atlas/browser and live delivery.

- Exact model: `kelvin-voigt-comsol63-deviatoric-zero-spin-ode`; SHA256 `080fa946ea5d7743b133b62bbd39098b6b50ecf09d835f1a9966fa9283b6f8da`.
- Independent prospective numerical study: [execution-v1/PLAN.md](execution-v1/PLAN.md).
- Main laboratory transport and public preset: [interface-v1/README.md](interface-v1/README.md).
- Independent review: [review-v1/INITIAL_REVIEW.md](review-v1/INITIAL_REVIEW.md); scientific approval is pending actual native/Wasm evidence.

The original COMSOL manual and equation images remain private, with public source links and hashes. No vendor code is executed or redistributed. Parameters are illustrative; no experimental validation, FE/MPM hosting, finite rotation, thermal/fractional response or broad parameter qualification is claimed.
