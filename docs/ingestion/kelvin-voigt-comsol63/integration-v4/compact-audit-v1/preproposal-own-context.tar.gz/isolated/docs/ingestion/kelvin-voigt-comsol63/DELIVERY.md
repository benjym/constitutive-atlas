# Kelvin–Voigt COMSOL 6.3 — delivery ledger

Lead: coordinating parent /root; claimed 2026-11-02. Follow [the exact assigned checklist](CHECKLIST.md), pinned in [assignment.json](assignment.json). Exact selected model: ordinary isotropic Kelvin–Voigt, deviatoric viscosity with purely elastic bulk, 3D infinitesimal strain, fixed frame/zero spin, dry total Cauchy stress, compression-positive Mandel components. Intended native/Wasm physical-time interfaces and main atlas laboratory; no finite rotations, thermal/fractional response, pore coupling or experimental validation.

- [X] E0 — Claim/scope: parent owns full delivery and shared integration; source worker and independent reviewer have distinct runs.
- [X] E1 — Source-complete packet source-v1; eleven private originals pinned and actual equation images inspected.
- [X] E2 — Explicit physical-time contract; prospective execution-v1 plan/cases/reference/policy frozen before compiled observations.
- [X] E3 — Exact v0.3 candidate080fa946…; nine analytical groups,720 interpreter stress comparisons and23 initialization rejection/recovery cases pass.
- [ ] E4 — Serial native/Wasm qualification, complete state, controls, rollback/restart and regressions.
- [ ] E5 — Independent nine-item agent review and exact approval.
- [ ] E6 — Normal catalogue, approval, source and main laboratory integration.
- [ ] E7 — Actual packaged browser controls, plots, replay, invalid/recovery and lifecycle qualification.
- [ ] E8 — Scoped commit/push, every required CI/Pages job, tested-upload/live hashes and actual live run.

Current owner: /root. Source and model are complete. Debug native/Wasm engines built from the frozen160-file source closure. The original study retained an incorrect native observation flag; binding-only execution-v2 repaired it, then exposed real creep-accuracy failures. All original inputs, raw responses, reports and limits are preserved. Independently reviewed execution-v3 tightens solver tolerances and explicitly raises the resource budget while preserving the43 physical cases, independent references and3e-8 strain/1Pa stress gates. Production Release native qualification is running under BUILD-kelvin-release-v2; Wasm follows only after native results are understood. Interface-v3 preserves prior bytes and handles tiny state/accumulated-strain roundoff without weakening physical accuracy or exact replay. Approval, packaged browser, publication and live verification remain pending. Disk interruption was recovered without deleting unrelated work. Raw source originals remain private.
