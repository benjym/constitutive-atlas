"""Generic tensor numerical primitives."""
