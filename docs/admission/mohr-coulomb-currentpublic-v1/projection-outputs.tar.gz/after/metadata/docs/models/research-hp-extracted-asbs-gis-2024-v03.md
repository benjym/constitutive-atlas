# HP/extracted-ASBS + GIS2024, f=0 — exact v0.3 draft

Local executable draft; independent scientific review is pending and unassigned. Actual packaged-browser acceptance remains pending. This selected pairing is distinct from the generic generalized-IGS discovery entry, IGS97, ISA and the alternative S=Y pairing.

Primary source: Mugele, Stutz & Mašín (2024), [DOI](https://doi.org/10.1016/j.compgeo.2024.106480), [institutional PDF](https://publikationen.bibliothek.kit.edu/1000171366/153009465). Published source SHA-256:39ec8356a26b82ae651be8feb4cdb3e49bb86ded9a850adc4c7eee5e9ec3bdc3. Eqs8–12,22,26–35,39–43 and AppendixB. The [source/formulation crosswalk](../ingestion/hypoplastic-generalized-igs-2024/README.md) records exact selected source, simultaneous compression-positive stress/strain/h conversion and unresolved decisions. This installation reuses that source reading; it is not fresh PDF review or author-code algorithm equivalence.

Definition SHA-256:439b785e1da3075209c6d5ca43a991a441463a915f31f2e9c77b5c6835e20dbc. Installed byte-for-byte from the [v0.3 research freeze](../reviews/gis2024-v03-research-freeze-v1/README.md). Small strain, fixed frame, zero spin; strain-path rate without physical clock/creep. Eighteen physical parameters plus numerical stress-error scale p_scale are explicit. Units and source locators stay in JSON; no model-specific handwritten kernel.

## Full state and preparation

Persistent state is sigma6,e,h6,Omega (14 scalar components) in Mandel order xx,yy,zz,sqrt(2)xy,sqrt(2)yz,sqrt(2)xz. The laboratory reconstructs an axisymmetric effective stress from radial stress and stress ratio; it cannot import arbitrary initial shear stress. All six h entries and Omega are explicit. Missing persistent history must reject; reversal does not reset memory. The illustrative origin is100kPa isotropic,e=.595,h=0,Omega=0. It is a software example, not a source-prepared specimen or Wichtmann calibration.

Strict computed norm(h)<=R, positive pressure/density conditions and Omega in[0,1] remain engine-domain gates. No memory projection, clamping or enlarged radius shell. Exact sphere arithmetic and finite integration remain support limits. Measurement matching supplies only observed stress/e/protocol; other internal-state inputs remain explicit and unprepared. JSON preserves full history and replays from its initial state; CSV is observations only.

## Bounded numerical evidence and retained failure

The [isolated v0.3](../reviews/gis2024-v03-research-freeze-v1/README.md), [mixed eleven-model](../reviews/gis2024-mixed-catalogue-v1/README.md) and [laboratory-route](../reviews/gis2024-laboratory-route-v1/README.md) packets have distinct scopes. Stage A passes26 independent instantaneous rates and60 laboratory cases per backend with full14state checks/native-Wasm parity. Tiny paths are1e-5strain or20Pa; this is not independent finite-trajectory accuracy, calibration or experimental validation.

The unchanged global drained1%/100increment/depth14run fails its first update and retains its initial full14point: [original failure and separate diagnostics](../reviews/gis2024-local-draft-v1/README.md). The named small example uses the already-qualified1e-5/8increment/depth20case, predating that failure. Its settings are visible and require explicit loading. The ordinary failure is not relabelled as a pass and global defaults are unchanged. Existing ten-model ordinary default gates remain separate.

No scientific admission, material applicability decision, measurement redistribution or deployment follows from this local draft. Independent review and specimen preparation remain open.
