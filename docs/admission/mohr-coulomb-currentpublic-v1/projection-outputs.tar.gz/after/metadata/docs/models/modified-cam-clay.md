# Modified Cam Clay: transcription and numerical dossier

Formulation ID: `modified-cam-clay`. Status: **transcribed; independent review pending**. This is a local, three-dimensional, infinitesimal-strain, rate-independent effective-stress law. Demonstration initialization is not an experimentally calibrated clay state.

## Sources and exact scope

- [Silbermann and Nagel, Modified Cam Clay report, 28 June 2023](https://github.com/ufz/ogs/blob/b5d0f115c75ee74a7cdbfad533625a550a416fda/web/content/docs/benchmarks/small-deformations/ModifiedCamClay/ModifiedCamClay_report.pdf), pinned to OpenGeoSys commit `b5d0f115c75ee74a7cdbfad533625a550a416fda`: equations 14–17, 30b and section 3.1. The downloaded PDF SHA-256 is `a03df6d05d777bfc4d484e6e12a2aecdebcbbf16bfca3b6601e699178620e9ce`. The PDF is linked, not redistributed. Equation 11 prints a single `M`; equation 30b uses `M^2`. This discrepancy was checked on rendered pages; the atlas uses `M^2`.
- [Itasca Modified Cam-Clay formulation](https://docs.itascacg.com/itasca930/common/models/camclay/doc/modelcamclay.html), accessed 2026-10-30: equations 15, 18–25 describe stiffness, yield and associated flow; equations 8 and 31 use different finite-step volume/hardening updates. These are primary formulation comparisons, not an executed external-code benchmark.

The endpoint stiffness, flow normalization by previous `pc`, exponential log-hardening and exponential volume update below are explicit project numerical choices. They are not claimed to be the complete algorithm of either source. The report's equation 12 normalizes flow by the gradient norm, whereas the atlas scales by `pc_n`; this changes the multiplier's normalization, not the associated flow direction.

## Conventions and full implemented equations

Stress and strain are compression positive. Tensor vectors are Mandel components `xx, yy, zz, xy, yz, xz`, with each tensor shear multiplied by `sqrt(2)`. Stresses are effective stresses in Pa; water pressure is not an internal variable of this constitutive law. Write `v=1+e`, `V=tr(de)`, `s=dev(sigma)`, `p=tr(sigma)/3` and `q^2=3 s:s/2`. A subscript `n` denotes the state at the start of the current internal increment.

The continuous stiffness, yield and flow direction correspond to the source equations cited above:

\[
K=vp/\kappa,\qquad G=\frac{3K(1-2\nu)}{2(1+\nu)},\qquad
f=q^2+M^2p(p-p_c),\qquad g=f.
\]

The atlas evaluates stiffness at the increment endpoint. Its normalized plastic volume increment is

\[
V_p=\gamma M^2(2p-p_c)/p_{c,n}.
\]

The complete residual system is

\[
\begin{aligned}
R_\sigma={}&\sigma-\sigma_n-KVI-2G\operatorname{dev}(de)
+\gamma\left(6Gs/p_{c,n}+KM^2(2p-p_c)I/p_{c,n}\right),\\
R_e={}&e-(1+e_n)e^{-V}+1,\\
R_{p_c}={}&p_c-p_{c,n}\exp[vV_p/(\lambda_c-\kappa)],\\
R_\gamma={}&\sqrt{\gamma^2+F^2}-\gamma+F,\qquad F=f/p_{ref}^2.
\end{aligned}
\]

At an exact root, the last equation enforces `gamma>=0`, `f<=0` and `gamma*f=0`. The first equation is endpoint elasticity plus normalized associated flow; the other two implement project exponential volume and log-hardening updates. Exponential bookkeeping does not extend the infinitesimal stress law to finite strain. The hardening residual discretizes `d(log pc)=v d(epsilon_v^p)/(lambda_c-kappa)`; it differs from a direct backward-Euler step on `pc` itself.

## State, parameters and initialization

| State | Units | Default and meaning |
| --- | --- | --- |
| `sigma` | Pa | Six effective Mandel stresses; initially `100 kPa I` |
| `e` | 1 | Void ratio `.7`; current specific volume is `1+e` |
| `pc` | Pa | Preconsolidation pressure `200 kPa` |
| `gamma` | 1 | Local normalized multiplier, initially zero; reset at every internal step |

| Parameter | Units | Default | Declared bounds |
| --- | --- | --- | --- |
| `p_ref` | Pa | `1e5` | `1 .. 1e10`; numerical stress scaling |
| `M` | 1 | `1.2` | `.1 .. 3`; critical-state slope |
| `lambda_c` | 1 | `.2` | `.001 .. 1`; virgin compression index |
| `kappa` | 1 | `.04` | `.0001 .. .5`; swelling index |
| `nu` | 1 | `.25` | `-.9 .. .49`; elastic Poisson ratio |

The indices use natural-log specific-volume conventions. The domain requires `e>0`, `lambda_c>kappa`, `p>1e-8 p_ref`, `pc>1e-8 p_ref` and `gamma>-1e-9`. The small negative multiplier allowance is a numerical iteration domain, not a plastic admissibility condition at a converged root. Initial yield admissibility is `f/p_ref^2<=1e-8`. Parameter bounds and these restrictions do not prove suitability for every stress path.

The initial default OCR is `pc/p=2`. No normal-consolidation-line intercept is supplied, and the code does not infer a specimen's loading history or thermodynamic consistency from `e,p,pc`. Users must supply an appropriate initialized state and parameter set. Invalid inputs or failed increments return the exact original state; partial internal substeps are not committed after failure.

## Independent scalar reduction

The original [v1 investigation](../PLASTICITY_VERIFICATION.md) checked isotropic and critical-state special cases. The expanded reference eliminates variables analytically and then uses scalar bisection; it never evaluates the DSL or calls its Newton solver for a reference value.

For one increment, `v=(1+e_n) exp(-V)` is known. Combining mean equilibrium and exponential hardening gives

\[
L(p)=\frac{vV-\kappa(1-p_n/p)}{\lambda_c-\kappa},\quad
p_c(p)=p_{c,n}\exp L(p),\quad
V_p(p)=V-\frac{\kappa}{v}(1-p_n/p).
\]

The elastic trial pressure is `p_el=p_n/(1-vV/kappa)`. At candidate pressure `p`, let `t(p)=s_n+2G(p)dev(de)`. On a plastic branch,

\[
\gamma(p)=\frac{p_{c,n}V_p(p)}{M^2(2p-p_c(p))},\qquad
s(p)=\frac{t(p)}{1+6G(p)\gamma(p)/p_{c,n}}.
\]

The remaining equation is `3 s(p):s(p)/2 + M^2 p(p-pc(p))=0`. Bisection brackets it between the elastic trial pressure and the pressure satisfying `pc(p)=2p`, treating wet-side hardening and dry-side softening separately. A multiplied expression avoids division by `2p-pc` during root search; the exact critical limit is handled separately. A positive finite elastic trial pressure is required by this reference. It is not a proof of uniqueness or global branch selection for arbitrary parameters or increments.

## Subdivision contract and evidence

The legacy residual integrator subdivides after nonlinear failure. Its `atlas_integrate` JSON now reports ordered `diagnostics.increment_fractions`: each accepted internal strain increment equals the requested increment times that fraction. For successful calls, fractions are positive and sum to one, with count equal to `substeps`. The shared legacy rate integrator reports its accepted midpoint half-steps in the same way. The physical-time and schedule APIs do not expose this legacy fraction trace.

On failure, this list describes partial internal progress and need not sum to one; the returned state still rolls back. The trace records actual accepted steps, not the rejected attempts or an accuracy estimate. No material clock is introduced. `gamma` in the returned state belongs to the final internal step, which is why replay must compare complete states in order.

The reference checker validates the successful trace and composes independent scalar solutions on exactly those increments. Every original one-step comparison remains in `unpartitioned_reference`, with an explicit applicability flag. In the retained yield-crossing example, one full implicit step gives `235946.077388 Pa`; the actual two half-steps and independently composed reference give `233234.691578 Pa`. A mismatching full-step value is therefore visible but is not used to reject agreement with a different, recorded discretization. This checks the constitutive solution on a partition; it does not validate how the solver chooses that partition.

The expanded suite has **57 cases**: the earlier special cases (with duplicate manual partition comparison removed), 36 wet/dry plastic tensor increments, two initially noncoaxial mixed cases, invalid-input rollback and two continuum isotropic refinement studies. Fixed stress/state/relative tolerances remain unchanged. Refinement checks remain separate from partition replay and require observed order above `.8` and final relative pressure error below `5e-4` at 64 steps. All 57 pass locally. The suite is a native CI regression gate, with matching increment-trace native/Wasm parity checks.

This reference is project-authored mathematical verification, not independent scientific review, an external implementation comparison or experimental validation. The initial five-model review gate remains open. Broader calibration, source review, generic error-controlled residual integration and finite-strain behavior remain outside this evidence claim.
